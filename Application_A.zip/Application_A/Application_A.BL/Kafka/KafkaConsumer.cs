﻿using Application_A.BL.Kafka;
using Application_A.Models;
using Confluent.Kafka;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application_A.BL.Serializers
{
    public class KafkaConsumer : IHostedService
    {
        private static IConsumer<int, Ticket> _consumer;
        public KafkaConsumer()
        {
            var config = new ConsumerConfig
            {
                BootstrapServers = "localhost",
                GroupId = $"AppName:{Guid.NewGuid().ToString()}",
                AutoOffsetReset = AutoOffsetReset.Earliest,
                EnableAutoCommit = true,
                ClientId = "2"

            };
            _consumer = new ConsumerBuilder<int, Ticket>(config)
                .SetValueDeserializer(new MsgPackDeserializer<Ticket>())
                .Build();


        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            _consumer.Subscribe("Test");
            Task.Factory.StartNew(() =>
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    try
                    {
                        var cr = _consumer.Consume(cancellationToken);
                        Console.WriteLine($"Consumed: {cr.Message.Value} At: {cr.TopicPartitionOffset}");
                        Console.WriteLine($"Object value is: id: {cr.Message.Value.Id}, MovieName: {cr.Message.Value.MovieName}, Seat number: {cr.Message.Value.SeatNumber}");
                    }
                    catch (ConsumeException e)
                    {
                        Console.WriteLine($"Error: {e.Error.Reason}");
                    }
                }


            }, cancellationToken);
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
