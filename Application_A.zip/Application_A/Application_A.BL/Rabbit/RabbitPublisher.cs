﻿using Application_A.BL.Interfaces;
using Application_A.Models;
using MessagePack;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using System;
using System.Threading.Tasks;
using IConnection = RabbitMQ.Client.IConnection;

namespace Application_A.BL.Services
{
    public class RabbitPublisher : IRabbitMqService, IDisposable
    {
        private readonly IConnection _connection;
        private readonly IModel _channel;

        public RabbitPublisher(IOptions<RabbitMqConfig> rOptions)
        {
            var factory = new ConnectionFactory()
            {
                HostName = rOptions.Value.Host,
                Port = rOptions.Value.Port
            };
            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();

            _channel.ExchangeDeclare("Test", ExchangeType.Fanout);

            _channel.QueueDeclare("ticket queue", true, false, autoDelete: false);
        }

        public void Dispose()
        {
            _channel?.Dispose();
            _connection?.Dispose();
        }


        public async Task PublshTicketRabbitAsync(Ticket t)
        {
            await Task.Factory.StartNew(() =>
            {
                byte[] bytes = MessagePackSerializer.Serialize(t);
                _channel.BasicPublish(exchange: "", routingKey: "ticket queue", body: bytes);
                Console.WriteLine($"Send obj: {t.Id}, {t.MovieName}, {t.SeatNumber}");
            });
        }
    }
    
}
