﻿using MessagePack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Application_A.Models
{
    [MessagePackObject]
    public class Ticket
    {
        [Key(0)]
        public int Id { get; set; }
        [Key(1)]
        public string MovieName { get; set; }
        [Key(2)]
        public int SeatNumber { get; set; }
    }
}
