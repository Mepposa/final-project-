﻿using Application_A.BL.Interfaces;
using Application_A.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Application_A.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TicketController : ControllerBase
    {
        private readonly ILogger<TicketController> _logger;
        private readonly IRabbitMqService _rabbitMq;

        public TicketController(ILogger<TicketController> logger, IRabbitMqService rabbitMq)
        {
            _logger = logger;
            _rabbitMq = rabbitMq;
        }

        [HttpPost("PublshTicket")]
        public async Task<IActionResult> SendTicket([FromBody] Ticket t)
        {
            await _rabbitMq.PublshTicketRabbitAsync(t);
            

            return Ok();
        }

    }
}
