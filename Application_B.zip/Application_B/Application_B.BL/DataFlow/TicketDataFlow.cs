﻿using Application_B.BL.Kafka;
using Application_B.Models;
using MessagePack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace Application_B.BL.DataFlow
{
        public class TicketDataFlow : ITicketDataFlow
        {

        private readonly IKafkaService _kafkaService;
            TransformBlock<byte[], Ticket> entryBlock;
            public TicketDataFlow(IKafkaService kafkaService)
            {
            _kafkaService = kafkaService;

            entryBlock = new TransformBlock<byte[], Ticket>(data => MessagePackSerializer.Deserialize<Ticket>(data));

                var enrichBlock = new TransformBlock<Ticket, Ticket>(t =>
                {
                    Random rd = new Random();

                    t.SeatNumber = rd.Next(0, 150);

                    return t;

                });

                var publishBlock = new ActionBlock<Ticket>(ticket =>
                {
                    Console.WriteLine($"Updated value:{ticket.SeatNumber}");
                    _kafkaService.SendTicketKafka(ticket);
                });

                var linkOptions = new DataflowLinkOptions()
                {
                    PropagateCompletion = true
                };


                entryBlock.LinkTo(enrichBlock, linkOptions);
                enrichBlock.LinkTo(publishBlock, linkOptions);
            }
            public async Task SendTicket(byte[] data)
            {
                var obj = MessagePackSerializer.Deserialize<Ticket>(data);
                Console.WriteLine($"Consumed: id:{obj.Id}, Movie Name:{obj.MovieName}, SeatNumber:{obj.SeatNumber}");
                await entryBlock.SendAsync(data);
            }

        }
}
