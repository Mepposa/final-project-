﻿using Application_B.BL.DataFlow;
using Application_B.Models;
using Confluent.Kafka;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Application_B.BL.Kafka
{
    public class KafkaService : IKafkaService
    {
        private static IProducer<int, Ticket> _producer;
        public KafkaService(IOptions<KafkaConfig> kOptions)
        {
            var config = new ProducerConfig()
            {
                BootstrapServers = kOptions.Value.BootstrapServers
            };

            _producer = new ProducerBuilder<int, Ticket>(config)
                .SetValueSerializer(new MsgPackSerializer<Ticket>())
                .Build();

            
        }
        public async Task SendTicketKafka(Ticket t)
        {
           await Task.Factory.StartNew(async () =>
            {
                Console.WriteLine($"Send Obj {t.Id}, {t.MovieName}, {t.SeatNumber}");
                await _producer.ProduceAsync("Test", new Message<int, Ticket>()
                {
                    Key = t.Id,
                    Value = t
                });               
            });  
        }
    }
}
