﻿using Application_B.Models;
using Confluent.Kafka;
using MessagePack;

namespace Application_B.BL.Kafka
{
    public class MsgPackSerializer<T> : ISerializer<T>
    {
        public byte[] Serialize(T data, SerializationContext context)
        {
            return MessagePackSerializer.Serialize(data);
        }
    }
}