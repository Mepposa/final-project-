﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application_B.Models
{
    public class RabbitMqConfig
    {
        public string Host { get; set; }

        public int Port { get; set; }
    }
}
