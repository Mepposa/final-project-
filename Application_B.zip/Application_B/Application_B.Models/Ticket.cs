﻿using MessagePack;
using System;

namespace Application_B.Models
{
    [MessagePackObject]
    public class Ticket
        {
            [Key(0)]
            public int Id { get; set; }
            [Key(1)]
            public string MovieName { get; set; }
            [Key(2)]
            public int SeatNumber { get; set; }
    }
}
